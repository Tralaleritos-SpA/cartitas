function TextMove() {

    return (
        <div className="text-move">
            <span>
                Descuento del 20% para usuarios registrados con correos de Duoc Uc

            </span>
        </div>
    );

}
export default TextMove